// ═══════════════════════════════════════════════════════════════
// SMART LOCK SYSTEM — MEGA ULTIMATE FINAL PASSWORD FIXED
// RFID + PIN + LCD + EEPROM + ADMIN MENU + PANIC + LOCKOUT
// ═══════════════════════════════════════════════════════════════

#include <SPI.h>
#include <MFRC522.h>
#include <Servo.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <Keypad.h>
#include <EEPROM.h>
#include <string.h>

// ───────────────────────────────────────────────────────────────
// PINS — ARDUINO MEGA
// ───────────────────────────────────────────────────────────────

#define SS_PIN        53
#define RST_PIN       49

#define SERVO_PIN      6
#define BUZZER_PIN     7
#define GREEN_LED      4
#define RED_LED        5

// ───────────────────────────────────────────────────────────────
// CONSTANTS
// ───────────────────────────────────────────────────────────────

#define PIN_MAX_LENGTH       8
#define MAX_USERS            4
#define MAX_FAILED_ATTEMPTS  6
#define LOCKOUT_TIME         30000UL

#define LOCK_POS             0
#define UNLOCK_POS           90

#define DOOR_OPEN_TIME       3000UL

#define PANIC_PIN            "911"

// EEPROM
#define EEPROM_ATTEMPTS      0
#define EEPROM_LOCKED        1
#define EEPROM_SOUND         2

#define EEPROM_SIG_1         10
#define EEPROM_SIG_2         11
#define EEPROM_USERS_START   20

#define EEPROM_SIGNATURE_1   0xAB
#define EEPROM_SIGNATURE_2   0xCD

// ───────────────────────────────────────────────────────────────
// OBJECTS
// ───────────────────────────────────────────────────────────────

MFRC522 mfrc522(SS_PIN, RST_PIN);
Servo doorServo;
LiquidCrystal_I2C lcd(0x27, 16, 2);

// ───────────────────────────────────────────────────────────────
// KEYPAD
// ───────────────────────────────────────────────────────────────

const byte ROWS = 4;
const byte COLS = 4;

char keys[ROWS][COLS] = {
  {'1','2','3','A'},
  {'4','5','6','B'},
  {'7','8','9','C'},
  {'*','0','#','D'}
};

byte rowPins[ROWS] = {22, 23, 24, 25};
byte colPins[COLS] = {26, 27, 28, 29};

Keypad keypad = Keypad(makeKeymap(keys), rowPins, colPins, ROWS, COLS);

// ───────────────────────────────────────────────────────────────
// USERS
// ───────────────────────────────────────────────────────────────

enum Role {
  ROLE_ADMIN,
  ROLE_USER,
  ROLE_GUEST
};

struct User {
  byte uid[4];
  const char* name;
  char pin[PIN_MAX_LENGTH + 1];
  Role role;
  bool active;
};

User users[MAX_USERS] = {
  {{0xFF,0x8D,0x82,0xC6}, "Youssef", "0000", ROLE_ADMIN, true},
  {{0x54,0xE0,0x34,0x1D}, "Ahmed",   "1234", ROLE_USER,  true},
  {{0x33,0x3A,0x24,0xAD}, "Karim",   "5678", ROLE_USER,  true},
  {{0xF3,0xFF,0xBC,0x1B}, "Guest",   "9999", ROLE_GUEST, true}
};

// ───────────────────────────────────────────────────────────────
// STATES
// ───────────────────────────────────────────────────────────────

enum SystemState {
  SYS_IDLE,
  SYS_LOCKED,

  SYS_ADMIN_LOGIN,
  SYS_ADMIN_MENU,

  SYS_ROLE_SELECT,
  SYS_USER_EDIT,

  SYS_CHANGE_PIN
};

SystemState currentState = SYS_IDLE;

// ───────────────────────────────────────────────────────────────
// VARIABLES
// ───────────────────────────────────────────────────────────────

char pinBuffer[PIN_MAX_LENGTH + 1];
byte pinIndex = 0;

byte failedAttempts = 0;

bool lockedOut = false;
bool silentMode = false;
bool adminLoginFromLockout = false;

byte selectedUser = 255;

unsigned long lockoutEnd = 0;
unsigned long lastLockDisplay = 0;

unsigned long lastKeyPressTime = 0;
const unsigned long KEY_DEBOUNCE_TIME = 80;

// ───────────────────────────────────────────────────────────────
// LCD
// ───────────────────────────────────────────────────────────────

void clearLCD() {
  lcd.setCursor(0, 0);
  lcd.print("                ");

  lcd.setCursor(0, 1);
  lcd.print("                ");
}

void show(const char* l1, const char* l2) {
  lcd.backlight();
  clearLCD();

  lcd.setCursor(0, 0);
  lcd.print(l1);

  lcd.setCursor(0, 1);
  lcd.print(l2);
}

void showPinStars() {
  lcd.setCursor(0, 1);
  lcd.print("                ");

  lcd.setCursor(0, 1);

  for (byte i = 0; i < pinIndex; i++) {
    lcd.print('*');
  }
}

// ───────────────────────────────────────────────────────────────
// PIN BUFFER
// ───────────────────────────────────────────────────────────────

void resetPinBuffer() {
  pinIndex = 0;
  pinBuffer[0] = '\0';
}

void addKeyToPin(char k) {
  if (pinIndex < PIN_MAX_LENGTH) {
    pinBuffer[pinIndex] = k;
    pinIndex++;
    pinBuffer[pinIndex] = '\0';
  }
}

// ───────────────────────────────────────────────────────────────
// KEY INPUT
// ───────────────────────────────────────────────────────────────

char getValidKey() {
  char k = keypad.getKey();

  if (k == 0) {
    return 0;
  }

  unsigned long currentTime = millis();

  if (currentTime - lastKeyPressTime < KEY_DEBOUNCE_TIME) {
    return 0;
  }

  lastKeyPressTime = currentTime;

  return k;
}

// ───────────────────────────────────────────────────────────────
// SOUND
// ───────────────────────────────────────────────────────────────

void beep(int f, int d) {
  if (silentMode) return;

  tone(BUZZER_PIN, f, d);
  delay(d + 20);
  noTone(BUZZER_PIN);
}

void forceBeep(int f, int d) {
  tone(BUZZER_PIN, f, d);
  delay(d + 20);
  noTone(BUZZER_PIN);
}

void adminSound() {
  beep(1200, 80);
  beep(1600, 80);
  beep(2200, 120);
}

void userSound() {
  beep(1000, 90);
  beep(1400, 90);
}

void guestSound() {
  beep(700, 120);
  beep(1000, 120);
}

void errorSound() {
  beep(500, 250);
}

void overrideSound() {
  forceBeep(2200, 100);
  forceBeep(1600, 100);
  forceBeep(2200, 100);
}

void alarmSound() {
  for (byte i = 0; i < 8; i++) {
    digitalWrite(RED_LED, HIGH);
    forceBeep(2200, 120);
    forceBeep(1200, 120);
    digitalWrite(RED_LED, LOW);
    delay(120);
  }
}

void loginSound(byte userIndex) {
  if (userIndex == 0) {
    adminSound();
  } else if (userIndex == 3) {
    guestSound();
  } else {
    userSound();
  }
}

// ───────────────────────────────────────────────────────────────
// LEDS
// ───────────────────────────────────────────────────────────────

void allLEDsOff() {
  digitalWrite(GREEN_LED, LOW);
  digitalWrite(RED_LED, LOW);
}

void flashGreen(byte t) {
  for (byte i = 0; i < t; i++) {
    digitalWrite(GREEN_LED, HIGH);
    delay(120);

    digitalWrite(GREEN_LED, LOW);
    delay(120);
  }
}

void flashRed(byte t) {
  for (byte i = 0; i < t; i++) {
    digitalWrite(RED_LED, HIGH);
    delay(120);

    digitalWrite(RED_LED, LOW);
    delay(120);
  }
}

// ───────────────────────────────────────────────────────────────
// EEPROM SYSTEM
// ───────────────────────────────────────────────────────────────

void saveSystemEEPROM() {
  EEPROM.update(EEPROM_ATTEMPTS, failedAttempts);
  EEPROM.update(EEPROM_LOCKED, lockedOut ? 1 : 0);
  EEPROM.update(EEPROM_SOUND, silentMode ? 1 : 0);
}

void loadSystemEEPROM() {
  failedAttempts = EEPROM.read(EEPROM_ATTEMPTS);

  if (failedAttempts > MAX_FAILED_ATTEMPTS) {
    failedAttempts = 0;
  }

  lockedOut = EEPROM.read(EEPROM_LOCKED) == 1;
  silentMode = EEPROM.read(EEPROM_SOUND) == 1;

  if (lockedOut) {
    lockoutEnd = millis() + LOCKOUT_TIME;
    currentState = SYS_LOCKED;
  }
}

// ───────────────────────────────────────────────────────────────
// EEPROM USERS — FIXED WITH SIGNATURE
// ───────────────────────────────────────────────────────────────

int userEEPROMBase(byte index) {
  return EEPROM_USERS_START + (index * 16);
}

void saveUserToEEPROM(byte index) {
  int base = userEEPROMBase(index);

  for (byte i = 0; i < 4; i++) {
    EEPROM.update(base + i, users[index].uid[i]);
  }

  for (byte i = 0; i < PIN_MAX_LENGTH + 1; i++) {
    EEPROM.update(base + 4 + i, users[index].pin[i]);
  }

  EEPROM.update(base + 13, (byte)users[index].role);
  EEPROM.update(base + 14, users[index].active ? 1 : 0);
}

void saveAllUsersToEEPROM() {
  EEPROM.update(EEPROM_SIG_1, EEPROM_SIGNATURE_1);
  EEPROM.update(EEPROM_SIG_2, EEPROM_SIGNATURE_2);

  for (byte i = 0; i < MAX_USERS; i++) {
    saveUserToEEPROM(i);
  }
}

bool validPinChars(const char* p) {
  if (p[0] == '\0') return false;

  for (byte i = 0; i < PIN_MAX_LENGTH; i++) {
    if (p[i] == '\0') return true;

    if (p[i] < '0' || p[i] > '9') {
      return false;
    }
  }

  return true;
}

void loadUsersFromEEPROM() {
  byte sig1 = EEPROM.read(EEPROM_SIG_1);
  byte sig2 = EEPROM.read(EEPROM_SIG_2);

  if (sig1 != EEPROM_SIGNATURE_1 || sig2 != EEPROM_SIGNATURE_2) {
    saveAllUsersToEEPROM();
    return;
  }

  for (byte index = 0; index < MAX_USERS; index++) {
    int base = userEEPROMBase(index);

    for (byte i = 0; i < 4; i++) {
      users[index].uid[i] = EEPROM.read(base + i);
    }

    for (byte i = 0; i < PIN_MAX_LENGTH + 1; i++) {
      users[index].pin[i] = (char)EEPROM.read(base + 4 + i);
    }

    users[index].pin[PIN_MAX_LENGTH] = '\0';

    byte savedRole = EEPROM.read(base + 13);

    if (savedRole <= ROLE_GUEST) {
      users[index].role = (Role)savedRole;
    }

    users[index].active = EEPROM.read(base + 14) == 1;

    if (!validPinChars(users[index].pin)) {
      if (index == 0) strcpy(users[index].pin, "0000");
      if (index == 1) strcpy(users[index].pin, "1234");
      if (index == 2) strcpy(users[index].pin, "5678");
      if (index == 3) strcpy(users[index].pin, "9999");

      saveUserToEEPROM(index);
    }
  }

  users[0].role = ROLE_ADMIN;
  users[0].active = true;

  if (!validPinChars(users[0].pin)) {
    strcpy(users[0].pin, "0000");
  }

  saveUserToEEPROM(0);
}

// ───────────────────────────────────────────────────────────────
// SERVO
// ───────────────────────────────────────────────────────────────

void openDoor() {
  doorServo.attach(SERVO_PIN);
  doorServo.write(UNLOCK_POS);
  delay(400);
  doorServo.detach();
}

void closeDoor() {
  doorServo.attach(SERVO_PIN);
  doorServo.write(LOCK_POS);
  delay(400);
  doorServo.detach();
}

// ───────────────────────────────────────────────────────────────
// USER SEARCH
// ───────────────────────────────────────────────────────────────

bool uidIsEmpty(byte* uid) {
  return uid[0] == 0 && uid[1] == 0 && uid[2] == 0 && uid[3] == 0;
}

int findUserByPIN(const char* pin) {
  if (pin[0] == '\0') return -1;

  for (byte i = 0; i < MAX_USERS; i++) {
    if (!users[i].active) continue;

    if (strcmp(users[i].pin, pin) == 0) {
      return i;
    }
  }

  return -1;
}

int findUserByUID(byte* uid, byte size) {
  if (size != 4) return -1;

  for (byte i = 0; i < MAX_USERS; i++) {
    if (!users[i].active) continue;
    if (uidIsEmpty(users[i].uid)) continue;

    bool match = true;

    for (byte j = 0; j < 4; j++) {
      if (users[i].uid[j] != uid[j]) {
        match = false;
        break;
      }
    }

    if (match) return i;
  }

  return -1;
}

bool pinBelongsToAdmin(const char* pin) {
  int index = findUserByPIN(pin);

  return index >= 0 && users[index].role == ROLE_ADMIN;
}

// ───────────────────────────────────────────────────────────────
// ACCESS
// ───────────────────────────────────────────────────────────────

void grantAccess(byte userIndex) {
  allLEDsOff();

  show("ACCESS GRANTED", users[userIndex].name);

  loginSound(userIndex);
  flashGreen(2);

  openDoor();

  digitalWrite(GREEN_LED, HIGH);

  show("DOOR OPEN", users[userIndex].name);

  delay(DOOR_OPEN_TIME);

  show("DOOR CLOSING", "PLEASE WAIT");

  closeDoor();

  digitalWrite(GREEN_LED, LOW);

  failedAttempts = 0;
  lockedOut = false;

  saveSystemEEPROM();
  resetPinBuffer();

  show("SCAN CARD", "OR ENTER PIN");
}

void triggerLockout() {
  lockedOut = true;
  lockoutEnd = millis() + LOCKOUT_TIME;
  currentState = SYS_LOCKED;

  saveSystemEEPROM();

  show("SYSTEM LOCKED", "TOO MANY TRIES");

  alarmSound();
  flashRed(5);
}

void denyAccess(const char* reason) {
  failedAttempts++;

  saveSystemEEPROM();

  show("ACCESS DENIED", reason);

  errorSound();
  flashRed(3);

  if (failedAttempts >= MAX_FAILED_ATTEMPTS) {
    triggerLockout();
  } else {
    delay(1000);
    resetPinBuffer();
    show("SCAN CARD", "OR ENTER PIN");
  }
}

// ───────────────────────────────────────────────────────────────
// PANIC
// ───────────────────────────────────────────────────────────────

void panicAlarm() {
  show("!!! PANIC !!!", "ALARM ACTIVE");

  for (byte i = 0; i < 8; i++) {
    digitalWrite(RED_LED, HIGH);
    forceBeep(2200, 150);
    forceBeep(1200, 150);
    digitalWrite(RED_LED, LOW);
    delay(120);
  }

  allLEDsOff();
  resetPinBuffer();

  show("SCAN CARD", "OR ENTER PIN");
}

// ───────────────────────────────────────────────────────────────
// LOCKOUT
// ───────────────────────────────────────────────────────────────

void clearLockout() {
  failedAttempts = 0;
  lockedOut = false;

  saveSystemEEPROM();

  currentState = SYS_IDLE;
  resetPinBuffer();
}

void handleLockout() {
  unsigned long now = millis();

  if (now >= lockoutEnd) {
    clearLockout();

    show("LOCKOUT ENDED", "TRY AGAIN");
    delay(1200);
    show("SCAN CARD", "OR ENTER PIN");

    return;
  }

  if (now - lastLockDisplay >= 1000) {
    lastLockDisplay = now;

    clearLCD();

    lcd.setCursor(0, 0);
    lcd.print("LOCKED ");
    lcd.print((lockoutEnd - now) / 1000);
    lcd.print(" SEC");

    lcd.setCursor(0, 1);
    lcd.print("* ADMIN LOGIN");

    digitalWrite(RED_LED, !digitalRead(RED_LED));
  }

  char k = getValidKey();

  if (k == '*') {
    resetPinBuffer();

    currentState = SYS_ADMIN_LOGIN;
    adminLoginFromLockout = true;

    show("ADMIN OVERRIDE", "PIN THEN #");
  }
}

// ───────────────────────────────────────────────────────────────
// ADMIN LOGIN
// ───────────────────────────────────────────────────────────────

void showAdminMenu() {
  show("1RESET 2USERS", "3SOUND *EXIT");
}

void handleAdminLogin(char k) {
  if (k == '*') {
    resetPinBuffer();

    if (adminLoginFromLockout) {
      adminLoginFromLockout = false;
      currentState = SYS_LOCKED;
      show("SYSTEM LOCKED", "* ADMIN LOGIN");
    } else {
      currentState = SYS_IDLE;
      show("SCAN CARD", "OR ENTER PIN");
    }

    return;
  }

  if (k == '#') {
    if (pinBelongsToAdmin(pinBuffer)) {
      resetPinBuffer();

      if (adminLoginFromLockout) {
        clearLockout();
        adminLoginFromLockout = false;

        show("OVERRIDE OK", "LOCK CLEARED");
        overrideSound();
        delay(1000);
      }

      currentState = SYS_ADMIN_MENU;
      showAdminMenu();

    } else {
      resetPinBuffer();

      if (adminLoginFromLockout) {
        show("BAD ADMIN PIN", "STILL LOCKED");
        errorSound();
        delay(1000);

        adminLoginFromLockout = false;
        currentState = SYS_LOCKED;
        show("SYSTEM LOCKED", "* ADMIN LOGIN");
      } else {
        currentState = SYS_IDLE;
        denyAccess("BAD ADMIN PIN");
      }
    }

    return;
  }

  if (k >= '0' && k <= '9') {
    addKeyToPin(k);
    showPinStars();
  } else {
    beep(500, 100);
  }
}

// ───────────────────────────────────────────────────────────────
// ADMIN MENU
// ───────────────────────────────────────────────────────────────

void handleAdminMenu() {
  char k = getValidKey();

  if (!k) return;

  beep(1500, 50);

  if (k == '1') {
    clearLockout();

    show("RESET DONE", "LOCK CLEARED");
    delay(1200);

    showAdminMenu();
  }

  else if (k == '2') {
    currentState = SYS_ROLE_SELECT;

    show("1ADMIN 2USER", "3GUEST *BACK");
  }

  else if (k == '3') {
    silentMode = !silentMode;

    saveSystemEEPROM();

    if (silentMode) {
      show("SOUND MODE", "MUTED");
    } else {
      show("SOUND MODE", "UNMUTED");
      forceBeep(1600, 100);
    }

    delay(1200);

    showAdminMenu();
  }

  else if (k == '*') {
    currentState = SYS_IDLE;

    resetPinBuffer();

    show("SCAN CARD", "OR ENTER PIN");
  }
}

// ───────────────────────────────────────────────────────────────
// ROLE SELECT
// ───────────────────────────────────────────────────────────────

void handleRoleSelect() {
  char k = getValidKey();

  if (!k) return;

  beep(1500, 50);

  if (k == '*') {
    currentState = SYS_ADMIN_MENU;
    showAdminMenu();
    return;
  }

  if (k == '1') {
    selectedUser = 0;
  }

  else if (k == '2') {
    selectedUser = 1;
  }

  else if (k == '3') {
    selectedUser = 3;
  }

  else {
    return;
  }

  currentState = SYS_USER_EDIT;

  show(users[selectedUser].name, "1PIN 2TOGGLE");
}

// ───────────────────────────────────────────────────────────────
// USER EDIT
// ───────────────────────────────────────────────────────────────

void handleUserEdit() {
  char k = getValidKey();

  if (!k) return;

  beep(1500, 50);

  if (k == '*') {
    currentState = SYS_ROLE_SELECT;

    show("1ADMIN 2USER", "3GUEST *BACK");

    return;
  }

  if (k == '1') {
    resetPinBuffer();

    currentState = SYS_CHANGE_PIN;

    show("NEW PIN", "TYPE THEN #");
  }

  else if (k == '2') {
    if (selectedUser == 0) {
      show("ADMIN", "CANT DISABLE");
      delay(1200);
    } else {
      users[selectedUser].active = !users[selectedUser].active;

      saveUserToEEPROM(selectedUser);

      if (users[selectedUser].active) {
        show("USER ENABLED", users[selectedUser].name);
      } else {
        show("USER DISABLED", users[selectedUser].name);
      }

      delay(1200);
    }

    show(users[selectedUser].name, "1PIN 2TOGGLE");
  }
}

// ───────────────────────────────────────────────────────────────
// CHANGE PIN
// ───────────────────────────────────────────────────────────────

void handleChangePin() {
  char k = getValidKey();

  if (!k) return;

  if (k == '*') {
    resetPinBuffer();

    currentState = SYS_USER_EDIT;

    show(users[selectedUser].name, "1PIN 2TOGGLE");

    return;
  }

  if (k == '#') {
    if (pinIndex == 0) {
      show("PIN EMPTY", "TRY AGAIN");

      delay(1200);

      show("NEW PIN", "TYPE THEN #");

      return;
    }

    if (strcmp(pinBuffer, PANIC_PIN) == 0) {
      show("911 RESERVED", "USE OTHER PIN");

      resetPinBuffer();

      delay(1200);

      show("NEW PIN", "TYPE THEN #");

      return;
    }

    strcpy(users[selectedUser].pin, pinBuffer);

    saveUserToEEPROM(selectedUser);

    resetPinBuffer();

    show("PIN UPDATED", users[selectedUser].name);

    loginSound(selectedUser);

    delay(1200);

    currentState = SYS_USER_EDIT;

    show(users[selectedUser].name, "1PIN 2TOGGLE");

    return;
  }

  if (k >= '0' && k <= '9') {
    addKeyToPin(k);
    showPinStars();
  } else {
    beep(500, 100);
  }
}

// ───────────────────────────────────────────────────────────────
// NORMAL INPUT
// ───────────────────────────────────────────────────────────────

void handleNormalKey(char k) {
  if (k == '*') {
    if (pinIndex == 0) {
      resetPinBuffer();

      currentState = SYS_ADMIN_LOGIN;

      show("ADMIN LOGIN", "PIN THEN #");
    } else {
      resetPinBuffer();

      show("PIN CLEARED", "");

      delay(700);

      show("SCAN CARD", "OR ENTER PIN");
    }

    return;
  }

  if (k == '#') {
    if (pinIndex == 0) {
      show("PIN EMPTY", "TRY AGAIN");

      delay(700);

      show("SCAN CARD", "OR ENTER PIN");

      return;
    }

    if (strcmp(pinBuffer, PANIC_PIN) == 0) {
      resetPinBuffer();

      panicAlarm();

      return;
    }

    int userIndex = findUserByPIN(pinBuffer);

    if (userIndex >= 0) {
      resetPinBuffer();

      grantAccess(userIndex);
    } else {
      denyAccess("WRONG PIN");
    }

    return;
  }

  if (k >= '0' && k <= '9') {
    if (pinIndex == 0) {
      show("ENTER PIN", "# CONFIRM");
    }

    addKeyToPin(k);

    showPinStars();
  } else {
    beep(500, 100);
  }
}

// ───────────────────────────────────────────────────────────────
// RFID
// ───────────────────────────────────────────────────────────────

void checkRFID() {
  if (!mfrc522.PICC_IsNewCardPresent()) {
    return;
  }

  if (!mfrc522.PICC_ReadCardSerial()) {
    return;
  }

  int userIndex = findUserByUID(
    mfrc522.uid.uidByte,
    mfrc522.uid.size
  );

  mfrc522.PICC_HaltA();
  mfrc522.PCD_StopCrypto1();

  if (userIndex >= 0) {
    grantAccess(userIndex);
  } else {
    denyAccess("BAD CARD");
  }
}

// ───────────────────────────────────────────────────────────────
// SETUP
// ───────────────────────────────────────────────────────────────

void setup() {
  Serial.begin(9600);

  SPI.begin();
  mfrc522.PCD_Init();

  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);

  allLEDsOff();

  lcd.init();
  lcd.backlight();

  resetPinBuffer();

  loadUsersFromEEPROM();
  loadSystemEEPROM();

  closeDoor();

  if (lockedOut) {
    currentState = SYS_LOCKED;
    show("SYSTEM LOCKED", "* ADMIN LOGIN");
  } else {
    currentState = SYS_IDLE;
    show("SMART LOCK", "READY");
    delay(1500);
    show("SCAN CARD", "OR ENTER PIN");
  }
}

// ───────────────────────────────────────────────────────────────
// LOOP
// ───────────────────────────────────────────────────────────────

void loop() {
  if (currentState == SYS_ADMIN_LOGIN) {
    char k = getValidKey();

    if (k) {
      handleAdminLogin(k);
    }

    return;
  }

  if (lockedOut || currentState == SYS_LOCKED) {
    currentState = SYS_LOCKED;

    handleLockout();

    return;
  }

  if (currentState == SYS_ADMIN_MENU) {
    handleAdminMenu();

    return;
  }

  if (currentState == SYS_ROLE_SELECT) {
    handleRoleSelect();

    return;
  }

  if (currentState == SYS_USER_EDIT) {
    handleUserEdit();

    return;
  }

  if (currentState == SYS_CHANGE_PIN) {
    handleChangePin();

    return;
  }

  char k = getValidKey();

  if (k) {
    handleNormalKey(k);
  }

  checkRFID();
}